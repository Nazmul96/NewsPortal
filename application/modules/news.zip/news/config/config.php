<?php
// module directory name
$HmvcConfig['news']["_title"]     = "news System";
$HmvcConfig['news']["_description"] = "Simple news System";
// register your module tables
// only register tables are imported while installing the module
$HmvcConfig['news']['_database'] = FALSE;
$HmvcConfig['news']["_tables"] = array( );