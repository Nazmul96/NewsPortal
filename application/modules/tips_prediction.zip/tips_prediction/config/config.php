<?php
// module directory name
$HmvcConfig['tips_prediction']["_title"]     = "tips_prediction System";
$HmvcConfig['tips_prediction']["_description"] = "Simple tips_prediction System";


// register your module tables
// only register tables are imported while installing the module
$HmvcConfig['tips_prediction']['_database'] = FALSE;
$HmvcConfig['tips_prediction']["_tables"] = array( );
$HmvcConfig['tips_prediction']['csrf_protection'] = FALSE;