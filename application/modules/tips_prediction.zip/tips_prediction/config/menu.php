<?php

// module name
$HmvcMenu["tips_prediction"] = array(
  
    "icon"           => " <i class='typcn typcn-film mr-2'></i>", 
    
    "photo_upload" => array( 
        "controller" => "media_controller",
        "method"     => "photo_upload",
        "permission" => "create"
    ),

    "tips_prediction_list" => array(
        "controller" => "media_controller",
        "method"     => "photo_list",
        "permission" => "read"
    ),

    "podcust" => array(
        "controller" => "Podcust_controller",
        "method"     => "list",
        "permission" => "read"
    ),

);
   

 