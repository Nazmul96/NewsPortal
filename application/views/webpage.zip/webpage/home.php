<div class="frame">
          <p class="text-wrapper">Fastest century in Ranji Trophy: Rishabh Pant, Riyan Parag headline list</p>
          <div class="frame-2">
            <div class="text-wrapper-2">News</div>
            <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
          </div>
          <div class="image-wrapper">
            <img class="image" src="<?php echo base_url()?>assets/newDesign/img/image-2.png" />
          </div>
        </div>
        <div class="frame-3">
          <div class="frame-4">
            <p class="sri-lanka-need">
              <span class="span">S</span>
              <span class="span"
                >ri Lanka&nbsp;&nbsp;need
                40&nbsp;&nbsp;runs&nbsp;&nbsp;in&nbsp;&nbsp;50&nbsp;&nbsp;balls&nbsp;&nbsp;at&nbsp;&nbsp;4.8 rpo</span
              >
            </p>
            <div class="frame-5">
              <p class="p">Zimbabwe Tour of Sri Lanka, 2024</p>
              <p class="element-odi-jan">2nd ODi |&nbsp;&nbsp;08 Jan 2024</p>
            </div>
            <div class="frame-6">
              <div class="frame-7">
                <div class="group">
                  <img class="screenshot" src="<?php echo base_url()?>assets/newDesign/img/screenshot-11-removebg-preview-1.png" />
                </div>
                <div class="frame-8">
                  <div class="text-wrapper-3">SRI LANKA</div>
                  <div class="element">169/7&nbsp;&nbsp;(41.4)</div>
                </div>
              </div>
              <div class="text-wrapper-4">VS</div>
              <div class="frame-7">
                <img class="zimbawe-removebg" src="<?php echo base_url()?>assets/newDesign/img/zimbawe-removebg-preview-1-1.png" />
                <div class="frame-8">
                  <div class="text-wrapper-3">ZIMBABWE</div>
                  <div class="text-wrapper-5">208(44.4)</div>
                </div>
              </div>
            </div>
            <div class="overlap-group">
              <div class="frame-9">
                <div class="frame-10">
                  <div class="ellipse"></div>
                  <div class="ellipse-2"></div>
                </div>
                <div class="text-wrapper-6">Live</div>
              </div>
            </div>
          </div>
          <div class="frame-4">
            <p class="sri-lanka-need">
              <span class="span">S</span>
              <span class="span"
                >ri Lanka&nbsp;&nbsp;need
                40&nbsp;&nbsp;runs&nbsp;&nbsp;in&nbsp;&nbsp;50&nbsp;&nbsp;balls&nbsp;&nbsp;at&nbsp;&nbsp;4.8 rpo</span
              >
            </p>
            <div class="frame-5">
              <p class="p">Zimbabwe Tour of Sri Lanka, 2024</p>
              <p class="element-odi-jan">2nd ODi |&nbsp;&nbsp;08 Jan 2024</p>
            </div>
            <div class="frame-6">
              <div class="frame-7">
                <div class="group">
                  <img class="screenshot" src="<?php echo base_url()?>assets/newDesign/img/screenshot-11-removebg-preview-1.png" />
                </div>
                <div class="frame-8">
                  <div class="text-wrapper-3">SRI LANKA</div>
                  <div class="element">169/7&nbsp;&nbsp;(41.4)</div>
                </div>
              </div>
              <div class="text-wrapper-4">VS</div>
              <div class="frame-7">
                <img class="zimbawe-removebg" src="<?php echo base_url()?>assets/newDesign/img/zimbawe-removebg-preview-1-1.png" />
                <div class="frame-8">
                  <div class="text-wrapper-3">ZIMBABWE</div>
                  <div class="text-wrapper-5">208(44.4)</div>
                </div>
              </div>
            </div>
            <div class="overlap-group">
              <div class="frame-9">
                <div class="frame-10">
                  <div class="ellipse"></div>
                  <div class="ellipse-2"></div>
                </div>
                <div class="text-wrapper-6">Live</div>
              </div>
            </div>
          </div>
          <div class="frame-4">
            <p class="sri-lanka-need">
              <span class="span">S</span>
              <span class="span"
                >ri Lanka&nbsp;&nbsp;need
                40&nbsp;&nbsp;runs&nbsp;&nbsp;in&nbsp;&nbsp;50&nbsp;&nbsp;balls&nbsp;&nbsp;at&nbsp;&nbsp;4.8 rpo</span
              >
            </p>
            <div class="frame-5">
              <p class="p">Zimbabwe Tour of Sri Lanka, 2024</p>
              <p class="element-odi-jan">2nd ODi |&nbsp;&nbsp;08 Jan 2024</p>
            </div>
            <div class="frame-6">
              <div class="frame-7">
                <div class="group">
                  <img class="screenshot" src="<?php echo base_url()?>assets/newDesign/img/screenshot-11-removebg-preview-1.png" />
                </div>
                <div class="frame-8">
                  <div class="text-wrapper-3">SRI LANKA</div>
                  <div class="element">169/7&nbsp;&nbsp;(41.4)</div>
                </div>
              </div>
              <div class="text-wrapper-4">VS</div>
              <div class="frame-7">
                <img class="zimbawe-removebg" src="<?php echo base_url()?>assets/newDesign/img/zimbawe-removebg-preview-1-1.png" />
                <div class="frame-8">
                  <div class="text-wrapper-3">ZIMBABWE</div>
                  <div class="text-wrapper-5">208(44.4)</div>
                </div>
              </div>
            </div>
            <div class="overlap-group">
              <div class="frame-9">
                <div class="frame-10">
                  <div class="ellipse"></div>
                  <div class="ellipse-2"></div>
                </div>
                <div class="text-wrapper-6">Live</div>
              </div>
            </div>
          </div>
          <div class="frame-4">
            <p class="sri-lanka-need">
              <span class="span">S</span>
              <span class="span"
                >ri Lanka&nbsp;&nbsp;need
                40&nbsp;&nbsp;runs&nbsp;&nbsp;in&nbsp;&nbsp;50&nbsp;&nbsp;balls&nbsp;&nbsp;at&nbsp;&nbsp;4.8 rpo</span
              >
            </p>
            <div class="frame-5">
              <p class="p">Zimbabwe Tour of Sri Lanka, 2024</p>
              <p class="element-odi-jan">2nd ODi |&nbsp;&nbsp;08 Jan 2024</p>
            </div>
            <div class="frame-6">
              <div class="frame-7">
                <div class="group"><img class="screenshot" src="<?php echo base_url()?>assets/newDesign/img/screenshot-11-removebg-preview-1.png" /></div>
                <div class="frame-8">
                  <div class="text-wrapper-3">SRI LANKA</div>
                  <div class="element">169/7&nbsp;&nbsp;(41.4)</div>
                </div>
              </div>
              <div class="text-wrapper-4">VS</div>
              <div class="frame-7">
                <img class="zimbawe-removebg" src="<?php echo base_url()?>assets/newDesign/img/zimbawe-removebg-preview-1-1.png" />
                <div class="frame-8">
                  <div class="text-wrapper-3">ZIMBABWE</div>
                  <div class="text-wrapper-5">208(44.4)</div>
                </div>
              </div>
            </div>
            <div class="overlap-group">
              <div class="frame-9">
                <div class="frame-10">
                  <div class="ellipse"></div>
                  <div class="ellipse-2"></div>
                </div>
                <div class="text-wrapper-6">Live</div>
              </div>
            </div>
          </div>
          <div class="frame-4">
            <p class="sri-lanka-need">
              <span class="span">S</span>
              <span class="span"
                >ri Lanka&nbsp;&nbsp;need
                40&nbsp;&nbsp;runs&nbsp;&nbsp;in&nbsp;&nbsp;50&nbsp;&nbsp;balls&nbsp;&nbsp;at&nbsp;&nbsp;4.8 rpo</span
              >
            </p>
            <div class="frame-5">
              <p class="p">Zimbabwe Tour of Sri Lanka, 2024</p>
              <p class="element-odi-jan">2nd ODi |&nbsp;&nbsp;08 Jan 2024</p>
            </div>
            <div class="frame-6">
              <div class="frame-7">
                <div class="group"><img class="screenshot" src="<?php echo base_url()?>assets/newDesign/img/screenshot-11-removebg-preview-1.png" /></div>
                <div class="frame-8">
                  <div class="text-wrapper-3">SRI LANKA</div>
                  <div class="element">169/7&nbsp;&nbsp;(41.4)</div>
                </div>
              </div>
              <div class="text-wrapper-4">VS</div>
              <div class="frame-7">
                <img class="img" src="<?php echo base_url()?>assets/newDesign/img/zimbawe-removebg-preview-1.png" />
                <div class="frame-8">
                  <div class="text-wrapper-3">ZIMBABWE</div>
                  <div class="text-wrapper-5">208(44.4)</div>
                </div>
              </div>
            </div>
            <div class="overlap-group">
              <div class="frame-9">
                <div class="frame-10">
                  <div class="ellipse"></div>
                  <div class="ellipse-2"></div>
                </div>
                <div class="text-wrapper-6">Live</div>
              </div>
            </div>
          </div>
        </div>
        <div class="frame-11">
          <div class="text-wrapper-7">Cricket</div>
          <img class="chevron-down" src="<?php echo base_url()?>assets/newDesign/img/chevron-down.svg" />
        </div>
        <div class="div-wrapper"><div class="text-wrapper-8">Advertisement</div></div>
        <div class="frame-12"><div class="text-wrapper-8">Advertisement</div></div>
        <div class="frame-13"><div class="text-wrapper-9">Advertisements</div></div>
        <div class="frame-14">
          <div class="overlap-group-wrapper">
            <div class="frame-wrapper">
              <div class="frame-15">
                <p class="text-wrapper-10">
                  Premier League top scorers 2023-24 list: Erling Haaland, Mohamed Salah lead Golden Boot Race
                </p>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-26.png" />
              </div>
            </div>
          </div>
          <div class="text"></div>
          <div class="text-wrapper-11">Premier League</div>
          <div class="overlap">
            <div class="frame-16">
              <img class="news" src="<?php echo base_url()?>assets/newDesign/img/user-2.png" />
              <p class="AFC-asian-CUP">
                AFC Asian CUP 2023,Live steaming : watch indian football team in action<br />
                - full schedule
              </p>
            </div>
            <div class="frame-16">
              <img class="news" src="<?php echo base_url()?>assets/newDesign/img/user-2.png" />
              <p class="AFC-asian-CUP">
                AFC Asian CUP 2023,Live steaming : watch indian football team in action<br />
                - full schedule
              </p>
            </div>
          </div>
          <div class="frame-17">
            <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
            <p class="text-wrapper-12">
              AFC Asian CUP 2023,Live steaming : watch indian football team in action<br />
              - full schedule
            </p>
          </div>
          <div class="frame-18">
            <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
            <p class="text-wrapper-12">
              AFC Asian CUP 2023,Live steaming : watch indian football team in action<br />
              - full schedule
            </p>
          </div>
          <div class="frame-19">
            <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
            <p class="text-wrapper-12">
              AFC Asian CUP 2023,Live steaming : watch indian football team in action<br />
              - full schedule
            </p>
          </div>
          <div class="frame-20">
            <div class="frame-21">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-23">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-21">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-23">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-23">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-25">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
          </div>
        </div>
        <div class="frame-26">
          <div class="overlap-2">
            <div class="frame-27">
              <p class="text-wrapper-15">
                Adelaide Strikers vs Hobart hurricanes Dream 11 prediction - get fantasy tips for Big Bash league
                2023/24
              </p>
              <img class="image-3" src="<?php echo base_url()?>assets/newDesign/img/image-4-7.png" />
            </div>
            <div class="frame-28">
              <div class="text-wrapper-14">News</div>
              <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
            </div>
          </div>
          <div class="frame-29">
            <div class="text-wrapper-16">Cricket</div>
            <div class="frame-30">
              <div class="frame-31"><div class="text-wrapper-17">More</div></div>
              <div class="frame-31"><div class="text-wrapper-17">News</div></div>
              <div class="frame-32"><div class="text-wrapper-17">Features</div></div>
              <div class="frame-33"><div class="text-wrapper-18">Opinions</div></div>
            </div>
          </div>
          <div class="frame-34">
            <img class="line" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
            <div class="frame-35">
              <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
              <p class="text-wrapper-19">Fastest century in Ranji Trophy: Rishabh Pant, Riyan Rarag headline list</p>
            </div>
            <img class="line" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
            <div class="frame-36">
              <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
              <p class="text-wrapper-12">Fastest century in Ranji Trophy: Rishabh Pant, Riyan Rarag headline list</p>
            </div>
            <img class="line-2" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
          </div>
          <div class="frame-37">
            <img class="line" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
            <div class="frame-35">
              <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
              <p class="text-wrapper-19">Fastest century in Ranji Trophy: Rishabh Pant, Riyan Rarag headline list</p>
            </div>
            <img class="line" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
            <div class="frame-36">
              <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
              <p class="text-wrapper-12">Fastest century in Ranji Trophy: Rishabh Pant, Riyan Rarag headline list</p>
            </div>
            <img class="line-2" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
          </div>
          <div class="frame-38">
            <div class="frame-21">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
          </div>
          <div class="frame-40">
            <div class="frame-21">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
          </div>
        </div>
        <div class="frame-41">
          <div class="overlap-3">
            <div class="frame-27">
              <p class="text-wrapper-15">
                Underdog Triumphs in Stunning Upset, Rewriting the Script in Unforgettable Football Matchup
              </p>
              <div class="overlap-group-2"><img class="image-3" src="<?php echo base_url()?>assets/newDesign/img/image-5.png" /></div>
            </div>
            <div class="frame-42">
              <div class="text-wrapper-14">News</div>
              <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
            </div>
          </div>
          <div class="frame-43">
            <div class="text-wrapper-16">Football</div>
            <div class="frame-30">
              <div class="frame-31"><div class="text-wrapper-17">More</div></div>
              <div class="frame-31"><div class="text-wrapper-17">News</div></div>
              <div class="frame-32"><div class="text-wrapper-17">Features</div></div>
              <div class="frame-33"><div class="text-wrapper-18">Opinions</div></div>
            </div>
          </div>
          <div class="frame-44">
            <img class="line" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
            <div class="frame-35">
              <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
              <p class="text-wrapper-12">
                AFC Asian CUP 2023,Live steaming : watch indian football team in action<br />
                - full schedule
              </p>
            </div>
            <img class="line" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
            <div class="frame-36">
              <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
              <p class="text-wrapper-12">
                AFC Asian CUP 2023,Live steaming : watch indian football team in action<br />
                - full schedule
              </p>
            </div>
            <img class="line-2" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
          </div>
          <div class="frame-45">
            <img class="line" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
            <div class="frame-35">
              <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
              <p class="text-wrapper-12">
                AFC Asian CUP 2023,Live steaming : watch indian football team in action<br />
                - full schedule
              </p>
            </div>
            <img class="line" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
            <div class="frame-36">
              <img class="img-2" src="<?php echo base_url()?>assets/newDesign/img/news.png" />
              <p class="text-wrapper-12">
                AFC Asian CUP 2023,Live steaming : watch indian football team in action<br />
                - full schedule
              </p>
            </div>
            <img class="line-2" src="<?php echo base_url()?>assets/newDesign/img/line-4.svg" />
          </div>
          <div class="frame-46">
            <div class="frame-21">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-23">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-23">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-25">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
          </div>
          <div class="frame-47">
            <div class="frame-21">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-23">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-23">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22">
                <div class="img-wrapper"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-4.png" /></div>
              </div>
              <p class="text-wrapper-13">
                Argentina vs real madrid in Copa del Rey 2023-24 Round of 32 clash watch live streaming in india
              </p>
              <div class="frame-25">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
          </div>
        </div>
        <div class="frame-48">
          <div class="overlap-4">
            <div class="frame-49"><img class="image-4" src="<?php echo base_url()?>assets/newDesign/img/image-8-2.png" /></div>
            <p class="text-wrapper-20">
              U Mumba vs babang delhi K.C. dream11 prediction- get PKL 10 kabaddi fantasy tips
            </p>
            <div class="frame-50">
              <div class="text-wrapper-21">News</div>
              <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
            </div>
          </div>
          <div class="frame-51">
            <img class="image-4" src="<?php echo base_url()?>assets/newDesign/img/image-8-1.png" />
            <p class="text-wrapper-22">
              U Mumba vs babang delhi K.C. dream11 prediction- get PKL 10 kabaddi fantasy tips
            </p>
            <div class="frame-52">
              <div class="text-wrapper-21">News</div>
              <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
            </div>
          </div>
          <div class="frame-53">
            <img class="image-4" src="<?php echo base_url()?>assets/newDesign/img/image-8.png" />
            <p class="text-wrapper-23">
              U Mumba vs babang delhi K.C. dream11 prediction- get PKL 10 kabaddi fantasy tips
            </p>
            <div class="frame-54">
              <div class="text-wrapper-21">News</div>
              <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
            </div>
          </div>
          <div class="frame-55">
            <div class="text-wrapper-24">Kabaddi</div>
            <div class="frame-30">
              <div class="frame-31"><div class="text-wrapper-17">More</div></div>
              <div class="frame-31"><div class="text-wrapper-17">News</div></div>
              <div class="frame-32"><div class="text-wrapper-17">Features</div></div>
              <div class="frame-33"><div class="text-wrapper-18">Opinions</div></div>
            </div>
          </div>
        </div>
        



        



        <div class="text-wrapper-30">All Latest Score</div>
        <div class="frame-63">
            <div class="frame-24">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-24">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-21">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
            <div class="frame-21">
              <div class="frame-22"><img class="image-2" src="<?php echo base_url()?>assets/newDesign/img/image-3.png" /></div>
              <p class="text-wrapper-13">Live streaming, SA20 2024 begins on January 10: Where to watch</p>
              <div class="frame-39">
                <div class="text-wrapper-14">News</div>
                <img class="share" src="<?php echo base_url()?>assets/newDesign/img/share-1.png" />
              </div>
            </div>
        </div>
        <div class="frame-64"><div class="text-wrapper-31">Ads</div></div>
        <div class="rectangle-wrapper"><div class="rectangle-3"></div></div>